clear all;

% Load data
load data;

% Perform K-medoids clustering.
% The function provides visualization 
% to support up to 4 clusters.
k_medoids(data, 4);
