ELEC 425 - Assignment 2
November 4, 2018

Andrew McClelland (14amm5) - 10150229

Q1 - Implement K-medians
K-medians code is found in k_medians.m. The main program (the code calling k_medians.m) is found in  k_medians_main.m.

Q2 - Prove the EM Updating Algorithm Used in K-medians
Proof of K-medians minimizing the error function can be found in the PDF report.

Q3 - Implement K-medoids
K-medoids code is found in k_medoids.m. The main program (the code calling k_medoids.m) is found in  k_medoids_main.m.