ELEC 425 - Assignment 3
November 28, 2018

Andrew McClelland (14amm5) - 10150229

#activation_tanh.m
Used in forward propagation step to calculate activation of layer alpha using tanh function

#activation_tanh_gradient.m
Used to calculate gradients of error w.r.t. in backpropagation step using derivative of tanh function (gradient)

#feedforward_network_tanh.m
Main script that runs the network and fits using tanh functions

#compute_gradient_for_weights_and_one_layer_below.m
Used to calculate gradients w.r.t. W# and h# in backpropagation step

#weighted_sum.m
Calculate weighted sum of network parameters and layers in forward propagation step